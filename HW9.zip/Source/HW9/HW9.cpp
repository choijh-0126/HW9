// Copyright Epic Games, Inc. All Rights Reserved.

#include "HW9.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, HW9, "HW9" );
